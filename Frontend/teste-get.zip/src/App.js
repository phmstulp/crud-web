import React, {Component} from 'react';
import Api from './Api';

class App extends Component{

  state = {
    inst: [],  
  }

  async componentDidMount() {
    const response = await Api.get('produto');
    console.log(response);
    this.setState({inst: response.data.value});
    console.log(response.data.value);
  }

  render(){
    const { inst } = this.state;

    return (
      <div>
        <h1>Produtos Cadastrados na API</h1>

        {inst.map(is => (
          <li>
            {is.cdProduto}
            <p>
              {is.dsProduto}
            </p>

          </li>  
          
        ))}

      </div>
    )
  };
    
};


export default App;
